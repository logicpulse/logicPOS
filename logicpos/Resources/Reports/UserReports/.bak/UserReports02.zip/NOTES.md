Always remove
	1) ..\..\..\bin\Debug\Resources\Reports\UserReports\
	
	2) <BusinessObjectDataSource
	
	3) Styles
	
	from inherited reports 
	
PDF	Render Problems
	Use Wysiwyg